import React, { useState, useEffect } from 'react';
import ListVivienda from '../Viviendas/ListVivienda';
import './ListViviendasContainer.css';

const ListViviendasContainer = () => {
  const [propiedades, setPropiedades] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filtros, setFiltros] = useState({
    precioMin: '',
    precioMax: '',
    habitacionesMin: '',
    distrito: ''
  });
  const [paginacion, setPaginacion] = useState({
    pagina: 1,
    totalPaginas: 0,
    totalPropiedades: 0
  });
  const [distritos, setDistritos] = useState([]);

  // Función para cargar los distritos únicos
  useEffect(() => {
    const fetchDistritos = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/estadisticas');
        
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
        
        const data = await response.json();
        if (data.distribucion_distritos) {
          setDistritos(Object.keys(data.distribucion_distritos).sort());
        }
      } catch (err) {
        console.error("Error al cargar los distritos:", err);
      }
    };

    fetchDistritos();
  }, []);

  // Función para construir la URL con parámetros de filtro y paginación
  const construirURL = () => {
    const url = new URL('http://localhost:5000/api/propiedades');
    
    // Añadir parámetros de paginación
    url.searchParams.append('pagina', paginacion.pagina);
    url.searchParams.append('limite', 10); // Número fijo de elementos por página
    
    // Añadir filtros si tienen valor
    Object.entries(filtros).forEach(([key, value]) => {
      if (value) {
        url.searchParams.append(key, value);
      }
    });
    
    return url.toString();
  };

  // Función para cargar propiedades con filtros y paginación
  const fetchPropiedades = async () => {
    try {
      setLoading(true);
      const url = construirURL();
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }
      
      const data = await response.json();
      setPropiedades(data.propiedades || []);
      setPaginacion({
        pagina: data.pagina || 1,
        totalPaginas: data.total_paginas || 0,
        totalPropiedades: data.total || 0
      });
      setLoading(false);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  // Cargar propiedades cuando cambian los filtros o la página
  useEffect(() => {
    fetchPropiedades();
  }, [filtros, paginacion.pagina]);

  const handleFiltroChange = (e) => {
    const { name, value } = e.target;
    setFiltros(prevFiltros => ({
      ...prevFiltros,
      [name]: value
    }));
    // Resetear a la primera página al cambiar filtros
    setPaginacion(prev => ({...prev, pagina: 1}));
  };

  const resetFiltros = () => {
    setFiltros({
      precioMin: '',
      precioMax: '',
      habitacionesMin: '',
      distrito: ''
    });
    setPaginacion(prev => ({...prev, pagina: 1}));
  };

  const cambiarPagina = (nuevaPagina) => {
    if (nuevaPagina >= 1 && nuevaPagina <= paginacion.totalPaginas) {
      setPaginacion(prev => ({...prev, pagina: nuevaPagina}));
    }
  };

  return (
    <div className="list-viviendas-container">
      <div className="filtros-section">
        <h2>Filtros de búsqueda</h2>
        <div className="filtros-grid">
          <div className="filtro-grupo">
            <label htmlFor="precioMin">Precio mínimo</label>
            <input 
              type="number" 
              id="precioMin" 
              name="precioMin"
              placeholder="Ej: 150000"
              value={filtros.precioMin}
              onChange={handleFiltroChange}
            />
          </div>
          
          <div className="filtro-grupo">
            <label htmlFor="precioMax">Precio máximo</label>
            <input 
              type="number" 
              id="precioMax" 
              name="precioMax"
              placeholder="Ej: 500000"
              value={filtros.precioMax}
              onChange={handleFiltroChange}
            />
          </div>
          
          <div className="filtro-grupo">
            <label htmlFor="habitacionesMin">Habitaciones mínimas</label>
            <input 
              type="number" 
              id="habitacionesMin" 
              name="habitacionesMin"
              placeholder="Ej: 2"
              value={filtros.habitacionesMin}
              onChange={handleFiltroChange}
            />
          </div>
          
          <div className="filtro-grupo">
            <label htmlFor="distrito">Distrito</label>
            <select 
              id="distrito" 
              name="distrito"
              value={filtros.distrito}
              onChange={handleFiltroChange}
            >
              <option value="">Todos los distritos</option>
              {distritos.map(distrito => (
                <option key={distrito} value={distrito}>{distrito}</option>
              ))}
            </select>
          </div>
        </div>
        
        <button className="reset-filtros" onClick={resetFiltros}>
          Restablecer filtros
        </button>
      </div>

      <div className="lista-resultados">
        <h2>Resultados ({paginacion.totalPropiedades} propiedades)</h2>
        
        {loading ? (
          <div className="loading">Cargando propiedades...</div>
        ) : error ? (
          <div className="error">Error: {error}</div>
        ) : propiedades.length > 0 ? (
          <>
            <ListVivienda propiedades={propiedades} />
            
            {/* Controles de paginación */}
            {paginacion.totalPaginas > 1 && (
              <div className="paginacion">
                <button 
                  onClick={() => cambiarPagina(paginacion.pagina - 1)}
                  disabled={paginacion.pagina <= 1}
                >
                  Anterior
                </button>
                
                <span className="pagina-info">
                  Página {paginacion.pagina} de {paginacion.totalPaginas}
                </span>
                
                <button 
                  onClick={() => cambiarPagina(paginacion.pagina + 1)}
                  disabled={paginacion.pagina >= paginacion.totalPaginas}
                >
                  Siguiente
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="no-resultados">
            No se encontraron propiedades con los criterios de búsqueda.
          </div>
        )}
      </div>
    </div>
  );
};

export default ListViviendasContainer; 