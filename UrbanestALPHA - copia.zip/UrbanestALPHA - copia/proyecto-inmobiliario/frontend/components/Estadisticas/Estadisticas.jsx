import React, { useState, useEffect, useRef } from 'react';
import './Estadisticas.css';

const formatearPrecio = (precio) => {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0
  }).format(precio);
};

// Componente para gráfico de barras personalizado
const GraficoBarras = ({ data, etiquetas, colorBarras = '#4a90e2', altura = 300, titulo }) => {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // Limpiar canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    if (!data || data.length === 0) return;
    
    const maxValue = Math.max(...data);
    const barWidth = (canvas.width - 60) / data.length;
    const barMargin = barWidth * 0.1;
    const effectiveBarWidth = barWidth - (barMargin * 2);
    
    // Dibujar ejes
    ctx.beginPath();
    ctx.moveTo(40, 20);
    ctx.lineTo(40, altura - 40);
    ctx.lineTo(canvas.width - 20, altura - 40);
    ctx.strokeStyle = '#ccc';
    ctx.lineWidth = 1;
    ctx.stroke();
    
    // Dibujar barras
    data.forEach((valor, index) => {
      const barHeight = ((valor / maxValue) * (altura - 80));
      const x = 40 + (index * barWidth) + barMargin;
      const y = altura - 40 - barHeight;
      
      // Barra
      ctx.fillStyle = colorBarras;
      ctx.fillRect(x, y, effectiveBarWidth, barHeight);
      
      // Etiqueta en eje X (rotada para mejor visibilidad)
      ctx.save();
      ctx.translate(x + (effectiveBarWidth / 2), altura - 35);
      ctx.rotate(-Math.PI / 4);
      ctx.fillStyle = '#666';
      ctx.font = '10px Arial';
      ctx.textAlign = 'right';
      ctx.fillText(etiquetas[index], 0, 0);
      ctx.restore();
      
      // Valor encima de la barra
      ctx.fillStyle = '#333';
      ctx.font = '10px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(valor, x + (effectiveBarWidth / 2), y - 5);
    });
    
    // Título del gráfico
    if (titulo) {
      ctx.fillStyle = '#333';
      ctx.font = 'bold 12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(titulo, canvas.width / 2, 15);
    }
  }, [data, etiquetas, colorBarras, altura, titulo]);

  return (
    <canvas ref={canvasRef} width={800} height={altura} className="grafico-canvas"></canvas>
  );
};

// Componente para gráfico circular personalizado
const GraficoCircular = ({ data, etiquetas, colores, titulo }) => {
  const canvasRef = useRef(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // Limpiar canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    if (!data || data.length === 0) return;
    
    const total = data.reduce((sum, value) => sum + value, 0);
    const radius = Math.min(canvas.width, canvas.height) / 2 - 40;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    
    let startAngle = 0;
    
    // Dibujar segmentos
    data.forEach((value, index) => {
      const sliceAngle = (2 * Math.PI * value) / total;
      
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
      ctx.closePath();
      
      ctx.fillStyle = colores[index % colores.length];
      ctx.fill();
      
      // Dibujar etiqueta
      const middleAngle = startAngle + sliceAngle / 2;
      const labelX = centerX + (radius * 0.7 * Math.cos(middleAngle));
      const labelY = centerY + (radius * 0.7 * Math.sin(middleAngle));
      
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 12px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      const percentage = Math.round((value / total) * 100);
      if (percentage > 5) { // Solo mostrar etiqueta si el segmento es suficientemente grande
        ctx.fillText(`${percentage}%`, labelX, labelY);
      }
      
      startAngle += sliceAngle;
    });
    
    // Título del gráfico
    if (titulo) {
      ctx.fillStyle = '#333';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.fillText(titulo, centerX, 10);
    }
    
    // Leyenda
    const legendX = canvas.width - 150;
    const legendY = 60;
    
    etiquetas.forEach((label, index) => {
      const y = legendY + (index * 25);
      
      // Cuadrado de color
      ctx.fillStyle = colores[index % colores.length];
      ctx.fillRect(legendX, y, 15, 15);
      
      // Texto
      ctx.fillStyle = '#333';
      ctx.font = '12px Arial';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, legendX + 25, y + 7);
    });
    
  }, [data, etiquetas, colores, titulo]);

  return (
    <canvas ref={canvasRef} width={800} height={400} className="grafico-canvas"></canvas>
  );
};

const Estadisticas = () => {
  const [estadisticas, setEstadisticas] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [datosGraficoDistritos, setDatosGraficoDistritos] = useState({ valores: [], etiquetas: [] });
  
  // Colores para gráficos
  const coloresDistritos = [
    '#4a90e2', '#50e3c2', '#f5a623', '#8b572a', '#9013fe', '#b8e986', 
    '#bd10e0', '#7ed321', '#d0021b', '#4a4a4a', '#9b9b9b', '#f8e71c'
  ];

  useEffect(() => {
    const fetchEstadisticas = async () => {
      try {
        setLoading(true);
        const response = await fetch('http://localhost:5000/api/estadisticas');
        
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
        
        const data = await response.json();
        setEstadisticas(data);
        
        // Preparar datos para el gráfico de distritos
        if (data.distribucion_distritos) {
          const distritos = Object.keys(data.distribucion_distritos);
          const cantidades = Object.values(data.distribucion_distritos);
          
          // Ordenar por cantidad de propiedades (descendente)
          const indicesOrdenados = cantidades
            .map((_, index) => index)
            .sort((a, b) => cantidades[b] - cantidades[a]);
          
          // Tomar los 10 distritos con más propiedades para el gráfico
          const top10Indices = indicesOrdenados.slice(0, 10);
          const otrosIndices = indicesOrdenados.slice(10);
          
          let etiquetasGrafico = top10Indices.map(i => distritos[i]);
          let valoresGrafico = top10Indices.map(i => cantidades[i]);
          
          // Si hay más de 10 distritos, agrupar el resto como "Otros"
          if (otrosIndices.length > 0) {
            const otrosValor = otrosIndices.reduce((sum, i) => sum + cantidades[i], 0);
            etiquetasGrafico.push('Otros');
            valoresGrafico.push(otrosValor);
          }
          
          setDatosGraficoDistritos({
            valores: valoresGrafico,
            etiquetas: etiquetasGrafico
          });
        }
        
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchEstadisticas();
  }, []);

  if (loading) {
    return <div className="estadisticas-cargando">Cargando estadísticas...</div>;
  }

  if (error) {
    return <div className="estadisticas-error">Error: {error}</div>;
  }

  if (!estadisticas) {
    return <div className="estadisticas-error">No hay datos estadísticos disponibles.</div>;
  }

  // Calcular rangos de precios para el gráfico
  const calcularRangosPrecio = () => {
    if (!estadisticas || !estadisticas.precio_min_valor || !estadisticas.precio_max_valor) {
      return { valores: [], etiquetas: [] };
    }
    
    const min = estadisticas.precio_min_valor;
    const max = estadisticas.precio_max_valor;
    const rango = max - min;
    const numRangos = 6;
    const tamañoRango = rango / numRangos;
    
    // Inicializar contadores para cada rango
    let contadores = Array(numRangos).fill(0);
    let etiquetas = [];
    
    // Generar etiquetas de rango
    for (let i = 0; i < numRangos; i++) {
      const inicioRango = min + (i * tamañoRango);
      const finRango = min + ((i + 1) * tamañoRango);
      etiquetas.push(`${formatearPrecio(inicioRango)} - ${formatearPrecio(finRango)}`);
    }
    
    return { valores: [15, 25, 40, 30, 20, 10], etiquetas }; // Datos ficticios para demostración
  };
  
  const datosRangosPrecios = calcularRangosPrecio();

  return (
    <div className="estadisticas-container">
      <h1 className="estadisticas-titulo">Estadísticas del mercado inmobiliario</h1>
      
      <div className="estadisticas-resumen">
        <div className="estadistica-card">
          <div className="estadistica-valor">{estadisticas.total_propiedades}</div>
          <div className="estadistica-etiqueta">Propiedades</div>
        </div>
        
        <div className="estadistica-card">
          <div className="estadistica-valor">{estadisticas.precio_promedio}</div>
          <div className="estadistica-etiqueta">Precio promedio</div>
        </div>
        
        <div className="estadistica-card">
          <div className="estadistica-valor">{estadisticas.metros_promedio} m²</div>
          <div className="estadistica-etiqueta">Superficie promedio</div>
        </div>
        
        <div className="estadistica-card">
          <div className="estadistica-valor">{estadisticas.precio_max}</div>
          <div className="estadistica-etiqueta">Precio máximo</div>
        </div>
      </div>
      
      <div className="estadisticas-graficos">
        <div className="grafico-seccion">
          <h2>Distribución de propiedades por distrito</h2>
          <div className="grafico-container">
            <GraficoCircular 
              data={datosGraficoDistritos.valores} 
              etiquetas={datosGraficoDistritos.etiquetas}
              colores={coloresDistritos}
              titulo="Propiedades por distrito"
            />
          </div>
          <div className="grafico-descripcion">
            <p>Este gráfico muestra cómo se distribuyen las propiedades en los diferentes distritos de la ciudad. Las áreas con mayor oferta inmobiliaria pueden indicar zonas de alta demanda o desarrollo.</p>
          </div>
        </div>
        
        <div className="grafico-seccion">
          <h2>Distribución por rangos de precio</h2>
          <div className="grafico-container">
            <GraficoBarras 
              data={datosRangosPrecios.valores} 
              etiquetas={datosRangosPrecios.etiquetas}
              colorBarras="#50e3c2"
              titulo="Número de propiedades por rango de precio"
            />
          </div>
          <div className="grafico-descripcion">
            <p>La distribución de precios muestra en qué rangos se concentran la mayor cantidad de propiedades disponibles, ofreciendo una visión del mercado inmobiliario actual.</p>
          </div>
        </div>
      </div>
      
      <div className="estadisticas-comparativas">
        <h2>Comparativas de mercado</h2>
        
        <div className="comparativa-grid">
          <div className="comparativa-item">
            <h3>Precio promedio por m²</h3>
            <div className="comparativa-valor">
              {formatearPrecio(Math.round(estadisticas.precio_promedio_valor / estadisticas.metros_promedio))}/m²
            </div>
            <p>Este valor representa el precio medio por metro cuadrado en toda la ciudad, basado en las propiedades disponibles actualmente.</p>
          </div>
          
          <div className="comparativa-item">
            <h3>Rango de precios</h3>
            <div className="comparativa-rango">
              <span>{estadisticas.precio_min}</span>
              <div className="rango-barra">
                <div className="rango-indicador"></div>
              </div>
              <span>{estadisticas.precio_max}</span>
            </div>
            <p>La variación entre el precio mínimo y máximo da una idea de la diversidad del mercado inmobiliario.</p>
          </div>
        </div>
      </div>
      
      <div className="estadisticas-conclusiones">
        <h2>Conclusiones</h2>
        <p>
          El análisis de los datos inmobiliarios muestra un mercado diverso con un precio promedio de {estadisticas.precio_promedio}. 
          La mayoría de las propiedades se concentran en ciertos distritos, lo que puede indicar zonas de mayor demanda o desarrollo.
        </p>
        <p>
          El precio por metro cuadrado promedio es un indicador clave para compradores e inversores, permitiendo comparar propiedades 
          de diferentes tamaños y ubicaciones de manera más objetiva.
        </p>
      </div>
    </div>
  );
};

export default Estadisticas; 