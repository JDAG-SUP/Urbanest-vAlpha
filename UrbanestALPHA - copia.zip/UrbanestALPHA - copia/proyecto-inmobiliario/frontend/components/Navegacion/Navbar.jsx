import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <img src="/logo.svg" alt="Urbanest" className="logo-image" />
          <span className="logo-text">Urbanest<span className="highlight">vAlpha</span></span>
        </Link>

        <ul className="nav-menu">
          <li className="nav-item">
            <Link to="/" className="nav-link">Inicio</Link>
          </li>
          <li className="nav-item">
            <Link to="/propiedades" className="nav-link">Propiedades</Link>
          </li>
          <li className="nav-item">
            <Link to="/mapa" className="nav-link">Mapa</Link>
          </li>
          <li className="nav-item">
            <Link to="/predictor" className="nav-link predictor-link">Predictor de Precios</Link>
          </li>
          <li className="nav-item">
            <Link to="/estadisticas" className="nav-link">Estadísticas</Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar; 