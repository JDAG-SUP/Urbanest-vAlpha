import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import './PropiedadDetalle.css';

const formatearPrecio = (precio) => {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0
  }).format(precio);
};

const getEstadoClass = (estado) => {
  switch (estado) {
    case 'Reformado':
      return 'estado-reformado';
    case 'Buen estado':
      return 'estado-bueno';
    case 'A reformar':
      return 'estado-reformar';
    default:
      return '';
  }
};

const PropiedadDetalle = () => {
  const { id } = useParams();
  const [propiedad, setPropiedad] = useState(null);
  const [propiedadesSimilares, setPropiedadesSimilares] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPropiedad = async () => {
      try {
        setLoading(true);
        const response = await fetch(`http://localhost:5000/api/propiedades/${id}`);
        
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
        
        const data = await response.json();
        setPropiedad(data);
        
        // Cargar propiedades similares (del mismo distrito)
        fetchPropiedadesSimilares(data.distrito);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchPropiedad();
  }, [id]);

  const fetchPropiedadesSimilares = async (distrito) => {
    try {
      const url = new URL('http://localhost:5000/api/propiedades');
      url.searchParams.append('distrito', distrito);
      url.searchParams.append('limite', 4);
      
      const response = await fetch(url.toString());
      
      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }
      
      const data = await response.json();
      // Filtrar la propiedad actual de las similares
      const similares = data.propiedades.filter(p => p.id !== parseInt(id)).slice(0, 3);
      setPropiedadesSimilares(similares);
      setLoading(false);
    } catch (err) {
      console.error("Error al cargar propiedades similares:", err);
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="propiedad-cargando">Cargando información de la propiedad...</div>;
  }

  if (error) {
    return <div className="propiedad-error">Error: {error}</div>;
  }

  if (!propiedad) {
    return <div className="propiedad-error">No se encontró la propiedad solicitada.</div>;
  }

  // Generar imágenes aleatorias (en un caso real serían imágenes reales de la propiedad)
  const imagenes = [
    `https://source.unsplash.com/800x600/?apartment,interior,${propiedad.id}`,
    `https://source.unsplash.com/800x600/?apartment,living,${propiedad.id + 100}`,
    `https://source.unsplash.com/800x600/?apartment,kitchen,${propiedad.id + 200}`,
    `https://source.unsplash.com/800x600/?apartment,bedroom,${propiedad.id + 300}`
  ];

  return (
    <div className="propiedad-detalle-container">
      <div className="propiedad-navegacion">
        <Link to="/propiedades" className="volver-link">
          ← Volver a propiedades
        </Link>
      </div>
      
      <div className="propiedad-header">
        <div className="propiedad-titulo-principal">
          <h1>Piso de {propiedad.metros_cuadrados}m² con {propiedad.habitaciones} habitaciones</h1>
          <div className={`propiedad-estado ${getEstadoClass(propiedad.estado)}`}>
            {propiedad.estado}
          </div>
        </div>
        <p className="propiedad-ubicacion">{propiedad.distrito}</p>
        <div className="propiedad-precio-header">{propiedad.precio_formateado}</div>
      </div>
      
      <div className="propiedad-galeria">
        <div className="imagen-principal">
          <img src={imagenes[0]} alt="Imagen principal" />
        </div>
        <div className="imagenes-secundarias">
          {imagenes.slice(1).map((img, index) => (
            <div key={index} className="imagen-secundaria">
              <img src={img} alt={`Imagen ${index + 1}`} />
            </div>
          ))}
        </div>
      </div>
      
      <div className="propiedad-contenido">
        <div className="propiedad-caracteristicas">
          <h2>Características principales</h2>
          
          <div className="caracteristicas-grid">
            <div className="caracteristica-item">
              <div className="caracteristica-icono">🏠</div>
              <div className="caracteristica-info">
                <span className="caracteristica-valor">{propiedad.metros_cuadrados} m²</span>
                <span className="caracteristica-etiqueta">Superficie</span>
              </div>
            </div>
            
            <div className="caracteristica-item">
              <div className="caracteristica-icono">🛏️</div>
              <div className="caracteristica-info">
                <span className="caracteristica-valor">{propiedad.habitaciones}</span>
                <span className="caracteristica-etiqueta">Habitaciones</span>
              </div>
            </div>
            
            <div className="caracteristica-item">
              <div className="caracteristica-icono">🗓️</div>
              <div className="caracteristica-info">
                <span className="caracteristica-valor">{propiedad.antiguedad} años</span>
                <span className="caracteristica-etiqueta">Antigüedad</span>
              </div>
            </div>
            
            <div className="caracteristica-item">
              <div className="caracteristica-icono">📍</div>
              <div className="caracteristica-info">
                <span className="caracteristica-valor">{propiedad.distrito}</span>
                <span className="caracteristica-etiqueta">Distrito</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="propiedad-descripcion">
          <h2>Descripción</h2>
          <p>
            Magnífica vivienda ubicada en el distrito de {propiedad.distrito}, con {propiedad.habitaciones} habitaciones 
            y {propiedad.metros_cuadrados} metros cuadrados. La propiedad tiene una antigüedad de {propiedad.antiguedad} años 
            y se encuentra en {propiedad.estado.toLowerCase()}.
          </p>
          <p>
            Cuenta con excelente iluminación natural, espacios amplios y buena distribución. 
            La zona dispone de todos los servicios necesarios como transporte público, supermercados, 
            colegios y áreas verdes cercanas.
          </p>
        </div>
        
        <div className="propiedad-ubicacion-mapa">
          <h2>Ubicación</h2>
          <div className="mapa-placeholder">
            <iframe 
              title="Ubicación de la propiedad"
              width="100%" 
              height="100%" 
              frameBorder="0" 
              style={{border: 0}}
              src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=${propiedad.latitud},${propiedad.longitud}`} 
              allowFullScreen
            />
          </div>
        </div>
        
        <div className="propiedad-contacto">
          <h2>¿Te interesa esta propiedad?</h2>
          <p>
            Contacta con nosotros para más información o para concertar una visita.
          </p>
          <div className="contacto-botones">
            <a href={`tel:+573001234567`} className="btn-contacto telefono">
              <span className="icono">📞</span> Llamar ahora
            </a>
            <a href={`mailto:info@urbanest.com?subject=Interés en propiedad ${propiedad.id}`} className="btn-contacto email">
              <span className="icono">✉️</span> Enviar email
            </a>
          </div>
        </div>
        
        {propiedadesSimilares.length > 0 && (
          <div className="propiedades-similares">
            <h2>Propiedades similares</h2>
            <div className="similares-grid">
              {propiedadesSimilares.map(similar => (
                <Link key={similar.id} to={`/propiedad/${similar.id}`} className="similar-item">
                  <div className="similar-imagen">
                    <img src={`https://source.unsplash.com/300x200/?apartment,house,${similar.id}`} alt="Propiedad similar" />
                  </div>
                  <div className="similar-info">
                    <h3>{similar.metros_cuadrados}m² en {similar.distrito}</h3>
                    <p>{similar.habitaciones} hab. • {similar.estado}</p>
                    <div className="similar-precio">{similar.precio_formateado}</div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PropiedadDetalle; 