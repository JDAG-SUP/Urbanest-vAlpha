import pandas as pd
import json
import os
import pickle
import locale
from sklearn.linear_model import LinearRegression

# Configurar el formato de moneda para pesos colombianos
def format_cop(value):
    """Formatea un valor numérico como pesos colombianos (COP)"""
    return f"${value:,.0f} COP"

class BaseView:
    def __init__(self):
        self.data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'model', 'dataset_10k.csv')
        self.model_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '..', 'frontend', 'models', 'modelo_entrenado.pkl')

    def load_data(self):
        """Carga datos desde el archivo CSV"""
        try:
            return pd.read_csv(self.data_path)
        except Exception as e:
            print(f"Error al cargar datos: {e}")
            return pd.DataFrame()

class AnalisisView(BaseView):
    def obtener_estadisticas(self):
        """Obtiene estadísticas básicas de las propiedades"""
        df = self.load_data()
        if df.empty:
            return {}

        return {
            'precio_promedio': format_cop(round(df['precio'].mean(), 2)),
            'precio_promedio_valor': round(df['precio'].mean(), 2),
            'metros_promedio': round(df['metros_cuadrados'].mean(), 2),
            'total_propiedades': len(df),
            'precio_min': format_cop(df['precio'].min()),
            'precio_min_valor': df['precio'].min(),
            'precio_max': format_cop(df['precio'].max()),
            'precio_max_valor': df['precio'].max(),
            'distribucion_distritos': df['distrito'].value_counts().to_dict()
        }
    
    def obtener_propiedades(self, page=1, limit=20, filtros=None):
        """Obtiene propiedades con paginación y filtros opcionales
        
        Args:
            page: Número de página (empieza en 1)
            limit: Cantidad de propiedades por página
            filtros: Diccionario con filtros a aplicar
        """
        df = self.load_data()
        if df.empty:
            return {'propiedades': [], 'total': 0, 'pagina': page, 'total_paginas': 0}
        
        # Aplicar filtros si existen
        if filtros:
            if 'precioMin' in filtros and filtros['precioMin']:
                df = df[df['precio'] >= float(filtros['precioMin'])]
            if 'precioMax' in filtros and filtros['precioMax']:
                df = df[df['precio'] <= float(filtros['precioMax'])]
            if 'habitacionesMin' in filtros and filtros['habitacionesMin']:
                df = df[df['habitaciones'] >= int(filtros['habitacionesMin'])]
            if 'distrito' in filtros and filtros['distrito']:
                df = df[df['distrito'] == filtros['distrito']]
        
        # Calcular paginación
        total_propiedades = len(df)
        total_paginas = (total_propiedades + limit - 1) // limit
        
        # Validar página solicitada
        if page < 1:
            page = 1
        elif page > total_paginas and total_paginas > 0:
            page = total_paginas
        
        # Obtener slice de datos para la página solicitada
        start_idx = (page - 1) * limit
        end_idx = start_idx + limit
        df_paginado = df.iloc[start_idx:end_idx].copy()
        
        # Añadir campo de precio formateado
        df_paginado['precio_formateado'] = df_paginado['precio'].apply(format_cop)
        
        return {
            'propiedades': json.loads(df_paginado.to_json(orient='records')),
            'total': total_propiedades,
            'pagina': page,
            'total_paginas': total_paginas
        }
    
    def obtener_propiedad(self, propiedad_id):
        """Obtiene una propiedad específica por ID"""
        df = self.load_data()
        if df.empty:
            return None
        
        propiedad = df[df['id'] == propiedad_id]
        if len(propiedad) == 0:
            return None
        
        # Crear una copia para no modificar el original
        propiedad_display = propiedad.copy()
        
        # Añadir campo de precio formateado
        propiedad_display['precio_formateado'] = propiedad_display['precio'].apply(format_cop)
        
        return json.loads(propiedad_display.to_json(orient='records'))[0]

class ModelPredictView(BaseView):
    def __init__(self):
        super().__init__()
        self.model = self._load_model()
        
    def _load_model(self):
        """Carga el modelo entrenado desde el archivo PKL"""
        try:
            with open(self.model_path, 'rb') as file:
                return pickle.load(file)
        except Exception as e:
            print(f"Error al cargar el modelo: {e}")
            return None
    
    def predecir_precio(self, metros_cuadrados, habitaciones, antiguedad, distrito):
        """Predice el precio basado en las características dadas"""
        if self.model is None:
            return {"error": "Modelo no disponible"}
            
        df = self.load_data()
        if df.empty:
            return {"error": "Datos no disponibles"}
            
        # Preparar datos para la predicción (depende de cómo se entrenó el modelo)
        # Este es un ejemplo simple, ajustar según las características usadas en el entrenamiento
        try:
            # Convertir distrito a valor numérico (one-hot encoding simplificado)
            distritos = df['distrito'].unique()
            distrito_index = list(distritos).index(distrito) if distrito in distritos else -1
            
            if distrito_index == -1:
                return {"error": "Distrito no válido"}
                
            prediction = self.model.predict([[
                metros_cuadrados, 
                habitaciones, 
                antiguedad, 
                distrito_index
            ]])
            
            precio_estimado = round(float(prediction[0]), 2)
            
            return {
                "precio_estimado": precio_estimado,
                "precio_estimado_formateado": format_cop(precio_estimado),
                "caracteristicas": {
                    "metros_cuadrados": metros_cuadrados,
                    "habitaciones": habitaciones,
                    "antiguedad": antiguedad,
                    "distrito": distrito
                }
            }
        except Exception as e:
            return {"error": f"Error en la predicción: {str(e)}"} 