from flask import Flask, request, jsonify
import sys
import os

# Añadir el directorio raíz al path para poder importar módulos
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from view.views import AnalisisView, ModelPredictView

app = Flask(__name__)

# Configurar CORS para permitir peticiones desde el frontend
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# Ruta para obtener todas las propiedades
@app.route('/api/propiedades', methods=['GET'])
def get_propiedades():
    analisis_view = AnalisisView()
    
    # Obtener parámetros de paginación y filtros
    page = request.args.get('pagina', 1, type=int)
    limit = request.args.get('limite', 20, type=int)
    
    # Limitar el tamaño máximo de página para evitar sobrecarga
    if limit > 100:
        limit = 100
    
    # Recopilar filtros de la URL si existen
    filtros = {}
    for param in ['precioMin', 'precioMax', 'habitacionesMin', 'distrito']:
        if param in request.args:
            filtros[param] = request.args.get(param)
    
    return jsonify(analisis_view.obtener_propiedades(page=page, limit=limit, filtros=filtros))

# Ruta para obtener una propiedad específica
@app.route('/api/propiedades/<int:propiedad_id>', methods=['GET'])
def get_propiedad(propiedad_id):
    analisis_view = AnalisisView()
    propiedad = analisis_view.obtener_propiedad(propiedad_id)
    if propiedad is None:
        return jsonify({'error': 'Propiedad no encontrada'}), 404
    return jsonify(propiedad)

# Ruta para obtener estadísticas
@app.route('/api/estadisticas', methods=['GET'])
def get_estadisticas():
    analisis_view = AnalisisView()
    return jsonify(analisis_view.obtener_estadisticas())

# Ruta para realizar predicciones de precios
@app.route('/api/predecir', methods=['POST'])
def predecir_precio():
    data = request.get_json()
    
    # Validar datos de entrada
    if not all(k in data for k in ('metros_cuadrados', 'habitaciones', 'antiguedad', 'distrito')):
        return jsonify({'error': 'Datos incompletos'}), 400
        
    try:
        metros_cuadrados = float(data['metros_cuadrados'])
        habitaciones = int(data['habitaciones'])
        antiguedad = int(data['antiguedad'])
        distrito = data['distrito']
    except (ValueError, TypeError):
        return jsonify({'error': 'Formato de datos inválido'}), 400
    
    # Realizar predicción
    model_view = ModelPredictView()
    resultado = model_view.predecir_precio(metros_cuadrados, habitaciones, antiguedad, distrito)
    
    if 'error' in resultado:
        return jsonify(resultado), 400
        
    return jsonify(resultado)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000) 