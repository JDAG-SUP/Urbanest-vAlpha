import pandas as pd
import json
import os
import pickle
import locale
from catboost import CatBoostRegressor, CatBoostClassifier

# Configurar el formato de moneda para pesos colombianos
def format_cop(value):
    """Formatea un valor numérico como pesos colombianos (COP)"""
    return f"${value:,.0f} COP"

class BaseView:
    def __init__(self):
        self.data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'model', 'dataset_10k.csv')
        self.model_precio_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '..', 'frontend', 'models', 'modelo_precio.pkl')
        self.model_tipo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '..', 'frontend', 'models', 'modelo_tipo.pkl')

    def load_data(self):
        """Carga datos desde el archivo CSV"""
        try:
            return pd.read_csv(self.data_path)
        except Exception as e:
            print(f"Error al cargar datos: {e}")
            return pd.DataFrame()

class AnalisisView(BaseView):
    def obtener_estadisticas(self):
        """Obtiene estadísticas básicas de las propiedades"""
        df = self.load_data()
        if df.empty:
            return {}

        return {
            'precio_promedio': format_cop(round(df['precio'].mean(), 2)),
            'precio_promedio_valor': round(df['precio'].mean(), 2),
            'metros_promedio': round(df['metros_cuadrados'].mean(), 2),
            'total_propiedades': len(df),
            'precio_min': format_cop(df['precio'].min()),
            'precio_min_valor': df['precio'].min(),
            'precio_max': format_cop(df['precio'].max()),
            'precio_max_valor': df['precio'].max(),
            'distribucion_distritos': df['distrito'].value_counts().to_dict()
        }
    
    def obtener_propiedades(self, page=1, limit=20, filtros=None):
        """Obtiene propiedades con paginación y filtros opcionales
        
        Args:
            page: Número de página (empieza en 1)
            limit: Cantidad de propiedades por página
            filtros: Diccionario con filtros a aplicar
        """
        df = self.load_data()
        if df.empty:
            return {'propiedades': [], 'total': 0, 'pagina': page, 'total_paginas': 0}
        
        # Aplicar filtros si existen
        if filtros:
            if 'precioMin' in filtros and filtros['precioMin']:
                df = df[df['precio'] >= float(filtros['precioMin'])]
            if 'precioMax' in filtros and filtros['precioMax']:
                df = df[df['precio'] <= float(filtros['precioMax'])]
            if 'habitacionesMin' in filtros and filtros['habitacionesMin']:
                df = df[df['habitaciones'] >= int(filtros['habitacionesMin'])]
            if 'distrito' in filtros and filtros['distrito']:
                df = df[df['distrito'] == filtros['distrito']]
        
        # Calcular paginación
        total_propiedades = len(df)
        total_paginas = (total_propiedades + limit - 1) // limit
        
        # Validar página solicitada
        if page < 1:
            page = 1
        elif page > total_paginas and total_paginas > 0:
            page = total_paginas
        
        # Obtener slice de datos para la página solicitada
        start_idx = (page - 1) * limit
        end_idx = start_idx + limit
        df_paginado = df.iloc[start_idx:end_idx].copy()
        
        # Añadir campo de precio formateado
        df_paginado['precio_formateado'] = df_paginado['precio'].apply(format_cop)
        
        return {
            'propiedades': json.loads(df_paginado.to_json(orient='records')),
            'total': total_propiedades,
            'pagina': page,
            'total_paginas': total_paginas
        }
    
    def obtener_propiedad(self, propiedad_id):
        """Obtiene una propiedad específica por ID"""
        df = self.load_data()
        if df.empty:
            return None
        
        propiedad = df[df['id'] == propiedad_id]
        if len(propiedad) == 0:
            return None
        
        # Crear una copia para no modificar el original
        propiedad_display = propiedad.copy()
        
        # Añadir campo de precio formateado
        propiedad_display['precio_formateado'] = propiedad_display['precio'].apply(format_cop)
        
        return json.loads(propiedad_display.to_json(orient='records'))[0]

class ModelPredictView(BaseView):
    def __init__(self):
        super().__init__()
        self.model_precio, self.model_tipo = self._load_models()
        
    def _load_models(self):
        """Carga los modelos entrenados desde los archivos PKL"""
        try:
            with open(self.model_precio_path, 'rb') as file:
                modelo_precio = pickle.load(file)
                
            with open(self.model_tipo_path, 'rb') as file:
                modelo_tipo = pickle.load(file)
                
            return modelo_precio, modelo_tipo
        except Exception as e:
            print(f"Error al cargar los modelos: {e}")
            return None, None
    
    def predecir_precio(self, metros_cuadrados, habitaciones, antiguedad, distrito):
        """Predice el precio y tipo de propiedad (arriendo o venta) basado en las características dadas"""
        if self.model_precio is None or self.model_tipo is None:
            return {"error": "Modelos no disponibles"}
            
        df = self.load_data()
        if df.empty:
            return {"error": "Datos no disponibles"}
            
        # Preparar datos para la predicción
        try:
            # CatBoost maneja automáticamente las variables categóricas
            # Solo necesitamos preparar el formato correcto para las predicciones
            datos_prediccion = pd.DataFrame({
                'distrito': [distrito],
                'metros_cuadrados': [float(metros_cuadrados)],
                'habitaciones': [int(habitaciones)],
                'antiguedad': [int(antiguedad)]
            })
            
            # Predecir precio
            precio_estimado = self.model_precio.predict(datos_prediccion)[0]
            precio_estimado = round(float(precio_estimado), 2)
            
            # Determinar tipo de propiedad SIEMPRE basado en el umbral
            tipo_predicho_umbral = "Venta" if precio_estimado >= 99999999 else "Arriendo"
            
            # Obtener también la predicción del modelo (solo para mostrar probabilidades)
            probabilidades = self.model_tipo.predict_proba(datos_prediccion)[0]
            prob_arriendo = round(float(probabilidades[0]) * 100, 2)
            prob_venta = round(float(probabilidades[1]) * 100, 2)
            
            return {
                "precio_estimado": precio_estimado,
                "precio_estimado_formateado": format_cop(precio_estimado),
                "tipo_propiedad": tipo_predicho_umbral,  # Siempre usamos la clasificación por umbral
                "tipo_propiedad_modelo": "Venta" if self.model_tipo.predict(datos_prediccion)[0] == 1 else "Arriendo",  # Solo informativo
                "probabilidad_arriendo": f"{prob_arriendo}%",
                "probabilidad_venta": f"{prob_venta}%",
                "caracteristicas": {
                    "metros_cuadrados": metros_cuadrados,
                    "habitaciones": habitaciones,
                    "antiguedad": antiguedad,
                    "distrito": distrito
                }
            }
        except Exception as e:
            return {"error": f"Error en la predicción: {str(e)}"}