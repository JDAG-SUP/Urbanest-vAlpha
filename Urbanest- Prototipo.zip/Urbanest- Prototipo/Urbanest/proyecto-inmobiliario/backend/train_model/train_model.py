import pandas as pd
import numpy as np
import os
import pickle
from catboost import CatBoostRegressor, CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score, classification_report

def train_model():
    """Entrena un modelo CatBoost para predecir precios de propiedades y clasificar si son de arriendo o venta"""
    
    # Rutas de archivos
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(current_dir, '..', 'model', 'dataset_10k.csv')
    model_price_path = os.path.join(current_dir, '..', '..', 'frontend', 'models', 'modelo_precio.pkl')
    model_type_path = os.path.join(current_dir, '..', '..', 'frontend', 'models', 'modelo_tipo.pkl')
    
    # Verificar directorios y crear si no existen
    os.makedirs(os.path.dirname(model_price_path), exist_ok=True)
    
    # Cargar datos
    print(f"Cargando datos desde: {data_path}")
    df = pd.read_csv(data_path)
    
    # Verificar los datos cargados
    print(f"Datos cargados: {df.shape[0]} registros con {df.shape[1]} columnas")
    print(df.head())
    
    # Preparación de datos
    # Seleccionar características según requerimientos
    X = df[['distrito', 'metros_cuadrados', 'habitaciones', 'antiguedad']]
    y_precio = df['precio']
    
    # Crear etiqueta para el tipo de propiedad (arriendo o venta) basado en el precio
    # Si precio < 99,999,999 entonces es arriendo (0), sino es venta (1)
    df['tipo_propiedad'] = (df['precio'] >= 99999999).astype(int)
    y_tipo = df['tipo_propiedad']
    
    # Mostrar distribución de tipos de propiedad
    print(f"Propiedades de arriendo: {sum(y_tipo == 0)}")
    print(f"Propiedades de venta: {sum(y_tipo == 1)}")
    
    # Dividir en conjuntos de entrenamiento y prueba
    X_train, X_test, y_precio_train, y_precio_test, y_tipo_train, y_tipo_test = train_test_split(
        X, y_precio, y_tipo, test_size=0.2, random_state=42)
    
    print(f"Conjunto de entrenamiento: {X_train.shape[0]} registros")
    print(f"Conjunto de prueba: {X_test.shape[0]} registros")
    
    # Especificar características categóricas (solo distrito es categórica)
    cat_features = [0]  # Índice 0 corresponde a 'distrito'
    
    # 1. Entrenar modelo para predicción de precios (CatBoostRegressor)
    print("\nEntrenando modelo de predicción de precios...")
    model_precio = CatBoostRegressor(
        iterations=500,
        learning_rate=0.05,
        depth=6,
        loss_function='RMSE',
        verbose=100
    )
    
    model_precio.fit(
        X_train, y_precio_train,
        cat_features=cat_features,
        eval_set=(X_test, y_precio_test)
    )
    
    # Evaluar modelo de precios
    y_precio_pred = model_precio.predict(X_test)
    mse = mean_squared_error(y_precio_test, y_precio_pred)
    r2 = r2_score(y_precio_test, y_precio_pred)
    
    print(f"Error cuadrático medio: {mse:.2f}")
    print(f"Coeficiente de determinación (R²): {r2:.2f}")
    
    # 2. Entrenar modelo para clasificación de tipo de propiedad (CatBoostClassifier)
    print("\nEntrenando modelo de clasificación de tipo de propiedad...")
    model_tipo = CatBoostClassifier(
        iterations=300,
        learning_rate=0.05,
        depth=6,
        loss_function='Logloss',
        verbose=100
    )
    
    model_tipo.fit(
        X_train, y_tipo_train,
        cat_features=cat_features,
        eval_set=(X_test, y_tipo_test)
    )
    
    # Evaluar modelo de clasificación
    y_tipo_pred = model_tipo.predict(X_test)
    accuracy = accuracy_score(y_tipo_test, y_tipo_pred)
    print(f"Precisión del modelo de clasificación: {accuracy:.4f}")
    print("Reporte de clasificación:")
    print(classification_report(y_tipo_test, y_tipo_pred, target_names=['Arriendo', 'Venta']))
    
    # Mostrar características importantes
    print("\nImportancia de características para predicción de precios:")
    feature_importance_precio = model_precio.get_feature_importance()
    for feature, importance in zip(X.columns, feature_importance_precio):
        print(f"{feature}: {importance}")
        
    print("\nImportancia de características para clasificación de tipo:")
    feature_importance_tipo = model_tipo.get_feature_importance()
    for feature, importance in zip(X.columns, feature_importance_tipo):
        print(f"{feature}: {importance}")
    
    # Guardar modelos entrenados
    with open(model_price_path, 'wb') as file:
        pickle.dump(model_precio, file)
    
    with open(model_type_path, 'wb') as file:
        pickle.dump(model_tipo, file)
    
    print(f"Modelo de precios guardado en: {model_price_path}")
    print(f"Modelo de tipo de propiedad guardado en: {model_type_path}")
    
    return model_precio, model_tipo, model_price_path, model_type_path

if __name__ == "__main__":
    print("Iniciando entrenamiento de los modelos...")
    model_precio, model_tipo, precio_path, tipo_path = train_model()
    print("Entrenamiento completado con éxito.")