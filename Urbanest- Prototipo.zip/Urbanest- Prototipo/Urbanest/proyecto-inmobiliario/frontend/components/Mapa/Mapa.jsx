import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Link } from 'react-router-dom';
import 'leaflet/dist/leaflet.css';
import './Mapa.css';
import L from 'leaflet';

// Corregir el problema de iconos de Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Componente para actualizar la vista del mapa cuando cambia la posición central
const CentrarMapa = ({ posicion }) => {
  const map = useMap();
  useEffect(() => {
    if (posicion) {
      map.setView(posicion, map.getZoom());
    }
  }, [posicion, map]);
  return null;
};

const formatearPrecio = (precio) => {
  return new Intl.NumberFormat('es-ES', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0
  }).format(precio);
};

const Mapa = () => {
  const [propiedades, setPropiedades] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [posicionCentral, setPosicionCentral] = useState([40.4168, -3.7038]); // Madrid por defecto
  const [distritos, setDistritos] = useState([]);
  const [filtro, setFiltro] = useState('');
  const [totalPropiedades, setTotalPropiedades] = useState(0);

  // Cargar distritos una sola vez
  useEffect(() => {
    const fetchDistritos = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/estadisticas');
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
        
        const data = await response.json();
        if (data.distribucion_distritos) {
          setDistritos(['Todos', ...Object.keys(data.distribucion_distritos).sort()]);
        }
      } catch (err) {
        console.error("Error al cargar distritos:", err);
      }
    };

    fetchDistritos();
  }, []);

  // Cargar propiedades según el filtro seleccionado
  useEffect(() => {
    const fetchPropiedades = async () => {
      try {
        setLoading(true);
        
        // Construir URL con filtros si hay
        const url = new URL('http://localhost:5000/api/propiedades');
        url.searchParams.append('limite', 100); // Limitar a 100 marcadores para mejor rendimiento
        
        if (filtro && filtro !== 'Todos') {
          url.searchParams.append('distrito', filtro);
        }
        
        const response = await fetch(url.toString());
        
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
        
        const data = await response.json();
        setPropiedades(data.propiedades || []);
        setTotalPropiedades(data.total || 0);
        
        // Calcular la posición promedio para centrar el mapa
        if (data.propiedades && data.propiedades.length > 0) {
          const latitudes = data.propiedades.map(p => p.latitud);
          const longitudes = data.propiedades.map(p => p.longitud);
          const latitudPromedio = latitudes.reduce((a, b) => a + b, 0) / latitudes.length;
          const longitudPromedio = longitudes.reduce((a, b) => a + b, 0) / longitudes.length;
          setPosicionCentral([latitudPromedio, longitudPromedio]);
        }
        
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchPropiedades();
  }, [filtro]);

  const handleFiltroChange = (e) => {
    setFiltro(e.target.value);
  };

  if (loading && distritos.length === 0) {
    return <div className="mapa-cargando">Cargando mapa de propiedades...</div>;
  }

  if (error) {
    return <div className="mapa-error">Error al cargar el mapa: {error}</div>;
  }

  return (
    <div className="mapa-container">
      <h2 className="mapa-titulo">Mapa de propiedades</h2>
      
      <div className="mapa-controles">
        <div className="mapa-filtro">
          <label htmlFor="filtro-distrito">Filtrar por distrito:</label>
          <select 
            id="filtro-distrito" 
            value={filtro} 
            onChange={handleFiltroChange}
          >
            <option value="">Todos</option>
            {distritos.filter(d => d !== 'Todos').map(distrito => (
              <option key={distrito} value={distrito}>{distrito}</option>
            ))}
          </select>
        </div>
        
        <div className="mapa-total">
          {loading ? (
            <span>Cargando...</span>
          ) : (
            <span>Mostrando {propiedades.length} de {totalPropiedades} propiedades</span>
          )}
        </div>
      </div>
      
      <div className="mapa-wrapper">
        {loading ? (
          <div className="mapa-loading-overlay">Cargando propiedades...</div>
        ) : null}
        
        <MapContainer center={posicionCentral} zoom={13} className="mapa">
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          <CentrarMapa posicion={posicionCentral} />
          
          {propiedades.map(propiedad => (
            <Marker 
              key={propiedad.id} 
              position={[propiedad.latitud, propiedad.longitud]}
            >
              <Popup>
                <div className="mapa-popup">
                  <h3>{propiedad.distrito}</h3>
                  <p>
                    <strong>{propiedad.metros_cuadrados} m²</strong> · 
                    <strong> {propiedad.habitaciones} hab.</strong> · 
                    <strong> {propiedad.estado}</strong>
                  </p>
                  <p className="mapa-popup-precio">{formatearPrecio(propiedad.precio)}</p>
                  <Link to={`/propiedad/${propiedad.id}`} className="mapa-popup-link">
                    Ver detalles
                  </Link>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
      
      <div className="mapa-leyenda">
        <p>Se muestran {propiedades.length} de {totalPropiedades} propiedades en el mapa</p>
        <p className="mapa-nota">Nota: Para mejor rendimiento, se limita el número de marcadores mostrados.</p>
      </div>
    </div>
  );
};

export default Mapa; 