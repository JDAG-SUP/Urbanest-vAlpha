import React, { useState, useEffect } from 'react';
import './model.css';

const ModeloPredictivo = () => {
  const [formData, setFormData] = useState({
    metros_cuadrados: '',
    habitaciones: '',
    antiguedad: '',
    distrito: '',
    tipo_filtro: 'todos' // Nueva opción para filtrar por tipo de propiedad
  });

  const [resultado, setResultado] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [distritos, setDistritos] = useState([]);
  const [cargandoDistritos, setCargandoDistritos] = useState(true);

  useEffect(() => {
    // Obtener la lista de distritos desde las estadísticas (más eficiente)
    const fetchDistritos = async () => {
      try {
        setCargandoDistritos(true);
        const response = await fetch('http://localhost:5000/api/estadisticas');
        if (!response.ok) {
          throw new Error('No se pudieron cargar los distritos');
        }
        
        const data = await response.json();
        if (data.distribucion_distritos) {
          // Ordenar los distritos alfabéticamente
          const distritosUnicos = Object.keys(data.distribucion_distritos).sort();
          setDistritos(distritosUnicos);
        } else {
          throw new Error('Formato de datos inesperado');
        }
      } catch (err) {
        console.error('Error al cargar distritos:', err);
        setError('Error al cargar la lista de distritos. Inténtalo de nuevo más tarde.');
      } finally {
        setCargandoDistritos(false);
      }
    };

    fetchDistritos();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validar los datos del formulario
    if (!formData.metros_cuadrados || !formData.habitaciones || !formData.antiguedad || !formData.distrito) {
      setError('Por favor, complete todos los campos');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch('http://localhost:5000/api/predecir', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Error en la predicción');
      }
      
      const data = await response.json();
      
      // Filtrar el resultado por tipo de propiedad si se ha seleccionado un filtro
      if (formData.tipo_filtro === 'arriendo' && data.tipo_propiedad === 'Venta') {
        setError('Esta propiedad se clasifica como Venta, pero has seleccionado filtrar solo por Arriendo.');
        setLoading(false);
        return;
      } else if (formData.tipo_filtro === 'venta' && data.tipo_propiedad === 'Arriendo') {
        setError('Esta propiedad se clasifica como Arriendo, pero has seleccionado filtrar solo por Venta.');
        setLoading(false);
        return;
      }
      
      setResultado(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const formatearPrecio = (precio) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      maximumFractionDigits: 0
    }).format(precio);
  };

  return (
    <div className="modelo-predictivo-container">
      <h2 className="modelo-titulo">Predictor de precios de vivienda</h2>
      <p className="modelo-descripcion">
        Completa los datos de la propiedad para obtener una estimación de su precio según nuestro modelo.
      </p>
      
      {error && (
        <div className="modelo-error">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="modelo-form">
        <div className="modelo-form-grupo">
          <label htmlFor="metros_cuadrados">Metros cuadrados</label>
          <input
            type="number"
            id="metros_cuadrados"
            name="metros_cuadrados"
            placeholder="Ej: 80"
            value={formData.metros_cuadrados}
            onChange={handleChange}
            min="1"
            required
          />
        </div>
        
        <div className="modelo-form-grupo">
          <label htmlFor="habitaciones">Número de habitaciones</label>
          <input
            type="number"
            id="habitaciones"
            name="habitaciones"
            placeholder="Ej: 2"
            value={formData.habitaciones}
            onChange={handleChange}
            min="0"
            required
          />
        </div>
        
        <div className="modelo-form-grupo">
          <label htmlFor="antiguedad">Antigüedad (años)</label>
          <input
            type="number"
            id="antiguedad"
            name="antiguedad"
            placeholder="Ej: 15"
            value={formData.antiguedad}
            onChange={handleChange}
            min="0"
            required
          />
        </div>
        
        <div className="modelo-form-grupo">
          <label htmlFor="distrito">Distrito</label>
          <select
            id="distrito"
            name="distrito"
            value={formData.distrito}
            onChange={handleChange}
            required
            disabled={cargandoDistritos}
          >
            <option value="">Seleccione un distrito</option>
            {cargandoDistritos ? (
              <option value="" disabled>Cargando distritos...</option>
            ) : (
              distritos.map(distrito => (
                <option key={distrito} value={distrito}>{distrito}</option>
              ))
            )}
          </select>
          {cargandoDistritos && (
            <div className="selector-loading">Cargando distritos...</div>
          )}
        </div>
        
        {/* Nueva opción para filtrar por tipo de propiedad */}
        <div className="modelo-form-grupo">
          <label htmlFor="tipo_filtro">Tipo de propiedad</label>
          <select
            id="tipo_filtro"
            name="tipo_filtro"
            value={formData.tipo_filtro}
            onChange={handleChange}
          >
            <option value="todos">Todos los tipos</option>
            <option value="arriendo">Solo arriendo</option>
            <option value="venta">Solo venta</option>
          </select>
        </div>
        
        <button 
          type="submit" 
          className="modelo-submit-btn"
          disabled={loading || cargandoDistritos}
        >
          {loading ? 'Calculando...' : 'Calcular precio estimado'}
        </button>
      </form>
      
      {resultado && !loading && (
        <div className="modelo-resultado">
          <h3>Precio estimado:</h3>
          <div className="modelo-precio-estimado">
            {resultado.precio_estimado_formateado}
          </div>
          
          {/* Mostrar tipo de propiedad (arriendo o venta) */}
          <div className="modelo-tipo-propiedad">
            <h3>Tipo de propiedad:</h3>
            <div className={`tipo-badge ${resultado.tipo_propiedad === 'Arriendo' ? 'arriendo' : 'venta'}`}>
              {resultado.tipo_propiedad}
            </div>
            <div className="modelo-probabilidades">
              <p>Probabilidad de arriendo: {resultado.probabilidad_arriendo}</p>
              <p>Probabilidad de venta: {resultado.probabilidad_venta}</p>
            </div>
          </div>
          
          <div className="modelo-detalles">
            <p>Basado en una propiedad de {resultado.caracteristicas.metros_cuadrados} m² con {resultado.caracteristicas.habitaciones} habitaciones, {resultado.caracteristicas.antiguedad} años de antigüedad en {resultado.caracteristicas.distrito}.</p>
          </div>
          <div className="modelo-disclaimer">
            <p>Nota: Este es un cálculo aproximado basado en nuestro modelo predictivo y los datos históricos disponibles.</p>
            <p><strong>Criterio de clasificación:</strong> Propiedades con precio menor a $99,999,999 COP son consideradas de arriendo, las demás son de venta.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModeloPredictivo;