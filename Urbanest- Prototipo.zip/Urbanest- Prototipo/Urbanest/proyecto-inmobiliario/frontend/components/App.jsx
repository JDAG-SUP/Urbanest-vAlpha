import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Navegacion/Navbar';
import ListViviendasContainer from './ContenedorBase0/ListViviendasContainer';
import Mapa from './Mapa/Mapa';
import ModeloPredictivo from './ModeloPredictivo/model';
import PropiedadDetalle from './PropiedadDetalle/PropiedadDetalle';
import Estadisticas from './Estadisticas/Estadisticas';
import './App.css';

const Inicio = () => {
  return (
    <div className="home-container">
      <div className="hero-section">
        <div className="hero-content">
          <h1>Encuentra tu hogar ideal con Urbanest<span className="highlight">vAlpha</span></h1>
          <p>
            Explora nuestra selección de propiedades, predice precios y toma decisiones informadas
            con la tecnología de inteligencia artificial.
          </p>
          <div className="hero-buttons">
            <a href="/propiedades" className="hero-button primary">Ver propiedades</a>
            <a href="/predictor" className="hero-button secondary">Predecir precios</a>
          </div>
        </div>
      </div>
      
      <div className="features-section">
        <div className="container">
          <h2>Descubre nuestras funcionalidades</h2>
          
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">🏠</div>
              <h3>Listado de propiedades</h3>
              <p>Explora todas las propiedades disponibles con filtros avanzados.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🗺️</div>
              <h3>Visualización en mapa</h3>
              <p>Localiza las propiedades en un mapa interactivo.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">📊</div>
              <h3>Predicción de precios</h3>
              <p>Utiliza nuestro modelo de IA para estimar el valor de una propiedad.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">📈</div>
              <h3>Estadísticas del mercado</h3>
              <p>Analiza el mercado inmobiliario con datos actualizados.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const App = () => {
  return (
    <Router>
      <div className="app">
        <Navbar />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Inicio />} />
            <Route path="/propiedades" element={<ListViviendasContainer />} />
            <Route path="/propiedad/:id" element={<PropiedadDetalle />} />
            <Route path="/mapa" element={<Mapa />} />
            <Route path="/predictor" element={<ModeloPredictivo />} />
            <Route path="/estadisticas" element={<Estadisticas />} />
          </Routes>
        </main>
        <footer className="footer">
          <div className="container">
            <p>&copy; {new Date().getFullYear()} Urbanest-vAlpha. Todos los derechos reservados.</p>
            <p>Este es un proyecto de demostración con fines educativos.</p>
          </div>
        </footer>
      </div>
    </Router>
  );
};

export default App; 